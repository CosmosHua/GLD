#!/usr/bin/env bash
python3 setup.py build develop
