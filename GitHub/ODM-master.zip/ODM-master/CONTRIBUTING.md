See https://github.com/OpenDroneMap/documents/blob/master/CONTRIBUTING.md
