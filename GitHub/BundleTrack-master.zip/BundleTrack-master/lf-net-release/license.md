This software  release is only for  research and evaluation purposes  only. For
any  form of  commercial  usage, prior  approval form  EPFL  and University  of
Victoria should be obtained in writing.
