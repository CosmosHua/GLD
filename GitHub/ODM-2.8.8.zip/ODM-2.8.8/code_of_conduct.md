See https://github.com/OpenDroneMap/documents/blob/master/CONDUCT.md
